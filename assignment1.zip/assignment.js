console.log("loaded"); //logs a message to console.

let rowNum; // Declaring variables
let colNum; // Declaring variables
let table; // Declaring variables
let btn; // Declaring variables


rowNum = document.getElementById("rowNum"); //getElementByID is assigning to the variable "rowNum" with DOM references.
colNum = document.getElementById("colNum"); //getElementByID is assigning to the variable "colNum" with DOM references.
table = document.getElementById("multTable"); //getElementByID is assigning to the variable "multTable" with DOM references.
btn = document.getElementById("btn"); //getElementByID is assigning to the variable "btn" with DOM references.
btn.addEventListener("click", generateTable); //associating the "generateTable" with the button click event. When user clicks on it it will execute the function.
function generateTable() { // Declaring the function
  // Getting row and column values
  let r = rowNum.value; //transfering the rowNum variable value to the r variable.
  let c = colNum.value; //transfering the colNum variable value to the c variable.

  table.innerHTML = "";   // Clears the table

  for (let i = 1; i < r; i++) { //for loop is used here. This loop will until i value is less than equal to r.
    let row = document.createElement("tr"); // creating HTML element which represent a row. It will assign it to the row variable.

    for (let j = 1; j < c; j++) { //for loop is used here. This loop will until j value is less than equal to c.
      let col = document.createElement("td"); // creating HTML element which represent a column. It will assign it to the column variable.
      col.innerHTML = i*j; //assigns the value of i*j to the innerHTML and is property of col element
      row.appendChild(col); //row element will include the appended col element.
    }

    table.appendChild(row); //table element will include the appended row element.
  }

  console.log("Table generated..."); //logs a message to the console.
}
window.onload = function() { //function is declared. This function runs when the window is loaded or opened. It will invoke the table already by setting value below.
  document.getElementById("rowNum").value =20; //This code sets the rowNum value which is set to 20 for now.
  document.getElementById("colNum").value =20; //This code sets the colNum value which is set to 20 for now.
  generateTable(); //calls the generateTable function.
}
